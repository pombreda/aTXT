aTXT
====

This is my script to make a format conversion doc(windows), docx, pdf to txt (plain format text).
